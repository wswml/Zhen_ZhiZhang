-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: cashbook
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book_members`
--

DROP TABLE IF EXISTS `book_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `book_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `joined_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_book_members_book_id` (`book_id`),
  KEY `ix_book_members_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_members`
--

LOCK TABLES `book_members` WRITE;
/*!40000 ALTER TABLE `book_members` DISABLE KEYS */;
INSERT INTO `book_members` VALUES (2,'1-u3wit23z',1,'owner','2026-07-20 12:51:06'),(9,'7-67pgrazt',7,'owner','2026-07-21 08:04:24'),(10,'1-u3wit23z',8,'member','2026-07-21 13:02:18');
/*!40000 ALTER TABLE `book_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` int NOT NULL AUTO_INCREMENT,
  `book_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `share_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `share_key_expires` datetime DEFAULT NULL,
  `user_id` int NOT NULL,
  `budget` float DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_books_book_id` (`book_id`),
  KEY `ix_books_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (2,'1-u3wit23z','家庭账本','12qtsjjp70','2026-07-28 05:40:19',1,5000,'2026-07-20 12:51:06'),(9,'7-67pgrazt','演示账本',NULL,NULL,7,5000,'2026-07-21 08:04:24'),(10,'1-u3wit23z','家庭账本','12suaq809k',NULL,8,0,'2026-07-20 12:51:06');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budgets`
--

DROP TABLE IF EXISTS `budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `budgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `book_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `month` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `budget` float DEFAULT NULL,
  `used` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgets`
--

LOCK TABLES `budgets` WRITE;
/*!40000 ALTER TABLE `budgets` DISABLE KEYS */;
INSERT INTO `budgets` VALUES (1,'7-67pgrazt',7,'2026-07',5000,0);
/*!40000 ALTER TABLE `budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fixed_flows`
--

DROP TABLE IF EXISTS `fixed_flows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fixed_flows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `book_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `month` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `money` float DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `flow_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribution` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fixed_flows`
--

LOCK TABLES `fixed_flows` WRITE;
/*!40000 ALTER TABLE `fixed_flows` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed_flows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flows`
--

DROP TABLE IF EXISTS `flows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `book_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `flow_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `money` float DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `invoice` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `origin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribution` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eliminate` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_flows_user_id` (`user_id`),
  KEY `ix_flows_book_id` (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1519 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flows`
--

LOCK TABLES `flows` WRITE;
/*!40000 ALTER TABLE `flows` DISABLE KEYS */;
INSERT INTO `flows` VALUES (607,7,'7-67pgrazt','2026-07-21','支出','餐饮','微信支付',35,'午餐-兰州拉面','',NULL,NULL,NULL,0),(608,7,'7-67pgrazt','2026-07-21','支出','交通','支付宝',5,'公交地铁','',NULL,NULL,NULL,0),(609,7,'7-67pgrazt','2026-07-20','支出','购物','微信支付',299,'超市采购','日用品和零食',NULL,NULL,NULL,0),(610,7,'7-67pgrazt','2026-07-19','收入','工资','银行卡',12000,'工资发放','7月工资',NULL,NULL,NULL,0),(611,7,'7-67pgrazt','2026-07-18','支出','娱乐','微信支付',88,'电影票','变形金刚',NULL,NULL,NULL,0),(612,7,'7-67pgrazt','2026-07-17','支出','餐饮','支付宝',168,'朋友聚餐','海底捞',NULL,NULL,NULL,0),(613,7,'7-67pgrazt','2026-07-16','支出','通讯','支付宝',100,'话费充值','',NULL,NULL,NULL,0),(614,7,'7-67pgrazt','2026-07-15','支出','居住','银行卡',2500,'房租','7月房租',NULL,NULL,NULL,0),(615,7,'7-67pgrazt','2026-07-14','收入','兼职','微信支付',800,'周末兼职收入','',NULL,NULL,NULL,0),(616,7,'7-67pgrazt','2026-07-11','支出','交通','支付宝',200,'打车费用','去机场',NULL,NULL,NULL,0),(617,7,'7-67pgrazt','2026-07-07','支出','购物','微信支付',459,'买衣服','优衣库T恤两件',NULL,NULL,NULL,0),(618,7,'7-67pgrazt','2026-07-01','收入','红包','微信支付',200,'朋友还钱','',NULL,NULL,NULL,0),(619,7,'7-67pgrazt','2026-07-21','支出','餐饮',NULL,2,'餐饮',NULL,NULL,NULL,'演示用户',0),(626,7,'7-67pgrazt','2026-07-21','支出','餐饮',NULL,555,'餐饮',NULL,NULL,NULL,'演示用户',0),(1209,1,'1-u3wit23z','2026-07-13','支出','交通','现金',7,'武汉地铁',NULL,NULL,'1-钱迹导入',NULL,0),(1210,1,'1-u3wit23z','2026-07-13','支出','其他','现金',8,'真水无香',NULL,NULL,'1-钱迹导入',NULL,0),(1211,1,'1-u3wit23z','2026-07-13','支出','其他','现金',25,'琪诚',NULL,NULL,'1-钱迹导入',NULL,0),(1212,1,'1-u3wit23z','2026-07-14','支出','交通','现金',7,'武汉地铁',NULL,NULL,'1-钱迹导入',NULL,0),(1213,1,'1-u3wit23z','2026-07-14','支出','其他','现金',8,'真水无香',NULL,NULL,'1-钱迹导入',NULL,0),(1214,1,'1-u3wit23z','2026-07-14','支出','餐饮','现金',86.8,'泰熙家会员储值',NULL,NULL,'1-钱迹导入',NULL,0),(1215,1,'1-u3wit23z','2026-07-14','支出','其他','现金',1.2,'摇优惠',NULL,NULL,'1-钱迹导入',NULL,0),(1216,1,'1-u3wit23z','2026-07-15','支出','转账','现金',1,'微信转账',NULL,NULL,'1-钱迹导入',NULL,0),(1217,1,'1-u3wit23z','2026-04-01','支出','购物','现金',19.9,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1218,1,'1-u3wit23z','2026-04-01','支出','购物','现金',35.9,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1219,1,'1-u3wit23z','2026-04-03','支出','购物','现金',0.01,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1220,1,'1-u3wit23z','2026-04-04','支出','餐饮','现金',6,'土家酱香饼',NULL,NULL,'1-钱迹导入',NULL,0),(1221,1,'1-u3wit23z','2026-04-04','支出','购物','现金',26,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1222,1,'1-u3wit23z','2026-04-04','支出','购物','现金',0.1,'淘宝闪购',NULL,NULL,'1-钱迹导入',NULL,0),(1223,1,'1-u3wit23z','2026-04-04','支出','购物','现金',17.1,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1224,1,'1-u3wit23z','2026-04-05','支出','餐饮','现金',19.7,'大米先生(东西湖万达店)',NULL,NULL,'1-钱迹导入',NULL,0),(1225,1,'1-u3wit23z','2026-04-05','支出','餐饮','现金',24.88,'大米先生(东西湖万达店)',NULL,NULL,'1-钱迹导入',NULL,0),(1226,1,'1-u3wit23z','2026-04-05','支出','购物','现金',68,'天猫',NULL,NULL,'1-钱迹导入',NULL,0),(1227,1,'1-u3wit23z','2026-04-06','支出','餐饮','现金',7.5,'小店',NULL,NULL,'1-钱迹导入',NULL,0),(1228,1,'1-u3wit23z','2026-04-07','支出','购物','现金',40,'文欣名烟名酒',NULL,NULL,'1-钱迹导入',NULL,0),(1229,1,'1-u3wit23z','2026-04-07','支出','通讯','现金',50,'中国电信',NULL,NULL,'1-钱迹导入',NULL,0),(1230,1,'1-u3wit23z','2026-04-07','支出','购物','现金',6,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1231,1,'1-u3wit23z','2026-04-07','支出','餐饮','现金',18,'扫码点单店主',NULL,NULL,'1-钱迹导入',NULL,0),(1232,1,'1-u3wit23z','2026-04-09','支出','餐饮','现金',31,'俊俊副食',NULL,NULL,'1-钱迹导入',NULL,0),(1233,1,'1-u3wit23z','2026-04-09','支出','购物','现金',6,'熙尚便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1234,1,'1-u3wit23z','2026-04-09','支出','餐饮','现金',6,'夏小胖鲜肚面馆',NULL,NULL,'1-钱迹导入',NULL,0),(1235,1,'1-u3wit23z','2026-04-10','支出','购物','现金',3,'武汉军秀超市',NULL,NULL,'1-钱迹导入',NULL,0),(1236,1,'1-u3wit23z','2026-04-10','支出','购物','现金',21.08,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1237,1,'1-u3wit23z','2026-04-10','支出','购物','现金',137,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1238,1,'1-u3wit23z','2026-04-11','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1239,1,'1-u3wit23z','2026-04-11','支出','餐饮','现金',28,'阿香米线(武汉金银湖万达餐厅)',NULL,NULL,'1-钱迹导入',NULL,0),(1240,1,'1-u3wit23z','2026-04-11','支出','购物','现金',75,'熙尚便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1241,1,'1-u3wit23z','2026-04-12','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1242,1,'1-u3wit23z','2026-04-12','支出','购物','现金',5.8,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1243,1,'1-u3wit23z','2026-04-13','支出','购物','现金',13,'井岗便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1244,1,'1-u3wit23z','2026-04-14','支出','购物','现金',6,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1246,1,'1-u3wit23z','2026-04-14','支出','餐饮','现金',180,'**红',NULL,NULL,'1-钱迹导入',NULL,0),(1247,1,'1-u3wit23z','2026-04-16','支出','其他','现金',1,'柏来科技',NULL,NULL,'1-钱迹导入',NULL,0),(1248,1,'1-u3wit23z','2026-04-16','支出','购物','现金',17.21,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1249,1,'1-u3wit23z','2026-04-16','支出','购物','现金',20,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1250,1,'1-u3wit23z','2026-04-18','支出','餐饮','现金',5,'味蒸香',NULL,NULL,'1-钱迹导入',NULL,0),(1251,1,'1-u3wit23z','2026-04-18','支出','其他','现金',16,'南京耀梵星网络科技有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1252,1,'1-u3wit23z','2026-04-18','支出','购物','现金',21.3,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1253,1,'1-u3wit23z','2026-04-18','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1254,1,'1-u3wit23z','2026-04-20','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1255,1,'1-u3wit23z','2026-04-21','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1256,1,'1-u3wit23z','2026-04-21','支出','购物','现金',22.8,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1257,1,'1-u3wit23z','2026-04-21','支出','娱乐','现金',15,'SCENE',NULL,NULL,'1-钱迹导入',NULL,0),(1258,1,'1-u3wit23z','2026-04-22','支出','购物','现金',4.99,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1259,1,'1-u3wit23z','2026-04-22','支出','餐饮','现金',16,'武汉市瑞安街长沙米粉',NULL,NULL,'1-钱迹导入',NULL,0),(1260,1,'1-u3wit23z','2026-04-23','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1261,1,'1-u3wit23z','2026-04-23','支出','餐饮','现金',10,'武汉市洪山区朱幺妹餐饮店(个体工商户)',NULL,NULL,'1-钱迹导入',NULL,0),(1262,1,'1-u3wit23z','2026-04-23','支出','购物','现金',4,'家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1263,1,'1-u3wit23z','2026-04-24','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1264,1,'1-u3wit23z','2026-04-24','支出','餐饮','现金',13.67,'禧燕热饮',NULL,NULL,'1-钱迹导入',NULL,0),(1265,1,'1-u3wit23z','2026-04-25','支出','购物','现金',12.99,'优鲜购生鲜超市',NULL,NULL,'1-钱迹导入',NULL,0),(1266,1,'1-u3wit23z','2026-04-25','支出','购物','现金',28.5,'熙尚便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1267,1,'1-u3wit23z','2026-04-26','支出','购物','现金',83.2,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1268,1,'1-u3wit23z','2026-04-26','支出','购物','现金',11.52,'欣万家购物',NULL,NULL,'1-钱迹导入',NULL,0),(1269,1,'1-u3wit23z','2026-04-26','支出','餐饮','现金',20,'谭记鲜卤猪脚饭',NULL,NULL,'1-钱迹导入',NULL,0),(1270,1,'1-u3wit23z','2026-04-26','支出','餐饮','现金',2,'俊俊副食',NULL,NULL,'1-钱迹导入',NULL,0),(1271,1,'1-u3wit23z','2026-04-27','支出','其他','现金',1,'快速退款申请_扫描全能王',NULL,NULL,'1-钱迹导入',NULL,0),(1272,1,'1-u3wit23z','2026-04-27','支出','购物','现金',107.8,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1273,1,'1-u3wit23z','2026-04-27','支出','购物','现金',31.5,'熙尚便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1274,1,'1-u3wit23z','2026-04-28','支出','餐饮','现金',12,'大米先生（湖北武汉荟聚店）',NULL,NULL,'1-钱迹导入',NULL,0),(1275,1,'1-u3wit23z','2026-04-28','支出','餐饮','现金',2,'大米先生（湖北武汉荟聚店）',NULL,NULL,'1-钱迹导入',NULL,0),(1276,1,'1-u3wit23z','2026-04-28','支出','购物','现金',9.9,'MINISO名创优品',NULL,NULL,'1-钱迹导入',NULL,0),(1277,1,'1-u3wit23z','2026-04-28','支出','交通','现金',5,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1278,1,'1-u3wit23z','2026-04-28','支出','交通','现金',4,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1279,1,'1-u3wit23z','2026-04-28','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1280,1,'1-u3wit23z','2026-04-29','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1281,1,'1-u3wit23z','2026-04-29','支出','交通','现金',8,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1282,1,'1-u3wit23z','2026-04-29','支出','购物','现金',24,'兰阳超市',NULL,NULL,'1-钱迹导入',NULL,0),(1283,1,'1-u3wit23z','2026-04-29','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1284,1,'1-u3wit23z','2026-04-29','支出','餐饮','现金',11,'武汉市江夏区煲仔饭',NULL,NULL,'1-钱迹导入',NULL,0),(1285,1,'1-u3wit23z','2026-04-29','支出','购物','现金',2,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1286,1,'1-u3wit23z','2026-05-02','支出','餐饮','现金',19.9,'九号',NULL,NULL,'1-钱迹导入',NULL,0),(1287,1,'1-u3wit23z','2026-05-02','支出','购物','现金',1,'Apple专区',NULL,NULL,'1-钱迹导入',NULL,0),(1288,1,'1-u3wit23z','2026-05-04','支出','餐饮','现金',13,'大秦来面',NULL,NULL,'1-钱迹导入',NULL,0),(1289,1,'1-u3wit23z','2026-05-04','收入','转账','现金',125,'转账',NULL,NULL,'1-钱迹导入',NULL,0),(1290,1,'1-u3wit23z','2026-05-05','支出','交通','现金',1.8,'哈啰',NULL,NULL,'1-钱迹导入',NULL,0),(1291,1,'1-u3wit23z','2026-05-07','支出','购物','现金',23.5,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1292,1,'1-u3wit23z','2026-05-07','支出','其他','现金',12,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1293,1,'1-u3wit23z','2026-05-08','支出','其他','现金',40,'现在',NULL,NULL,'1-钱迹导入',NULL,0),(1294,1,'1-u3wit23z','2026-05-08','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1295,1,'1-u3wit23z','2026-05-08','支出','购物','现金',1.88,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1296,1,'1-u3wit23z','2026-05-09','支出','购物','现金',3.02,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1297,1,'1-u3wit23z','2026-05-13','支出','购物','现金',6.5,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1299,1,'1-u3wit23z','2026-05-14','支出','其他','现金',9,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1300,1,'1-u3wit23z','2026-05-14','支出','购物','现金',10,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1301,1,'1-u3wit23z','2026-05-15','支出','其他','现金',10,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1302,1,'1-u3wit23z','2026-05-15','支出','购物','现金',11,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1303,1,'1-u3wit23z','2026-05-17','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1304,1,'1-u3wit23z','2026-05-17','支出','其他','现金',5.24,'项城市鲸软网络科技有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1305,1,'1-u3wit23z','2026-05-18','支出','购物','现金',4,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1306,1,'1-u3wit23z','2026-05-18','支出','购物','现金',6,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1307,1,'1-u3wit23z','2026-05-18','支出','餐饮','现金',13,'西式鸡扒饭',NULL,NULL,'1-钱迹导入',NULL,0),(1308,1,'1-u3wit23z','2026-05-18','支出','其他','现金',5.24,'项城市鲸软网络科技有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1309,1,'1-u3wit23z','2026-05-22','支出','通讯','现金',50,'中国电信',NULL,NULL,'1-钱迹导入',NULL,0),(1310,1,'1-u3wit23z','2026-05-23','支出','购物','现金',10,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1311,1,'1-u3wit23z','2026-05-23','支出','购物','现金',6,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1312,1,'1-u3wit23z','2026-05-23','支出','其他','现金',12,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1313,1,'1-u3wit23z','2026-05-25','支出','餐饮','现金',22.6,'单先森中式炸鸡',NULL,NULL,'1-钱迹导入',NULL,0),(1314,1,'1-u3wit23z','2026-05-25','支出','购物','现金',21.9,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1315,1,'1-u3wit23z','2026-05-26','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1316,1,'1-u3wit23z','2026-05-26','支出','购物','现金',22.2,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1317,1,'1-u3wit23z','2026-05-26','支出','其他','现金',23,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1318,1,'1-u3wit23z','2026-05-27','支出','购物','现金',4,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1319,1,'1-u3wit23z','2026-05-27','支出','其他','现金',12,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1320,1,'1-u3wit23z','2026-05-29','支出','其他','现金',13,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1321,1,'1-u3wit23z','2026-05-29','收入','转账','现金',200,'转账',NULL,NULL,'1-钱迹导入',NULL,0),(1322,1,'1-u3wit23z','2026-05-30','支出','购物','现金',20.2,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1323,1,'1-u3wit23z','2026-05-30','支出','购物','现金',8,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1324,1,'1-u3wit23z','2026-05-31','支出','其他','现金',13,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1325,1,'1-u3wit23z','2026-06-02','支出','其他','现金',10,'杭州深度求索人工智能基础技术研究有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1326,1,'1-u3wit23z','2026-06-04','支出','其他','现金',15,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1327,1,'1-u3wit23z','2026-06-04','支出','购物','现金',10,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1328,1,'1-u3wit23z','2026-06-05','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1329,1,'1-u3wit23z','2026-06-05','支出','购物','现金',9,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1330,1,'1-u3wit23z','2026-06-05','支出','其他','现金',8.5,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1331,1,'1-u3wit23z','2026-06-06','支出','其他','现金',3,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1332,1,'1-u3wit23z','2026-06-06','支出','购物','现金',1,'Apple专区',NULL,NULL,'1-钱迹导入',NULL,0),(1333,1,'1-u3wit23z','2026-06-07','支出','购物','现金',5,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1334,1,'1-u3wit23z','2026-06-07','支出','其他','现金',4,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1335,1,'1-u3wit23z','2026-06-08','支出','其他','现金',4,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1336,1,'1-u3wit23z','2026-06-08','支出','购物','现金',26,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1337,1,'1-u3wit23z','2026-06-08','支出','其他','现金',29.8,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1338,1,'1-u3wit23z','2026-06-09','支出','购物','现金',4,'满亿购超市',NULL,NULL,'1-钱迹导入',NULL,0),(1339,1,'1-u3wit23z','2026-06-09','支出','其他','现金',3,'校园一卡通',NULL,NULL,'1-钱迹导入',NULL,0),(1340,1,'1-u3wit23z','2026-06-09','支出','餐饮','现金',13,'西式鸡扒饭',NULL,NULL,'1-钱迹导入',NULL,0),(1341,1,'1-u3wit23z','2026-06-09','支出','购物','现金',8,'熙尚便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1342,1,'1-u3wit23z','2026-06-10','支出','餐饮','现金',17.5,'小店',NULL,NULL,'1-钱迹导入',NULL,0),(1343,1,'1-u3wit23z','2026-06-11','支出','餐饮','现金',52,'老柏泉小家常(吴家山店）',NULL,NULL,'1-钱迹导入',NULL,0),(1344,1,'1-u3wit23z','2026-06-12','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1345,1,'1-u3wit23z','2026-06-12','支出','购物','现金',6.5,'井岗便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1346,1,'1-u3wit23z','2026-06-12','支出','餐饮','现金',120.39,'美团',NULL,NULL,'1-钱迹导入',NULL,0),(1347,1,'1-u3wit23z','2026-06-12','收入','餐饮','现金',1.35,'美团',NULL,NULL,'1-钱迹导入',NULL,0),(1348,1,'1-u3wit23z','2026-06-13','支出','餐饮','现金',5,'小店',NULL,NULL,'1-钱迹导入',NULL,0),(1349,1,'1-u3wit23z','2026-06-13','支出','购物','现金',22.3,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1350,1,'1-u3wit23z','2026-06-13','支出','购物','现金',10,'武汉山姆超市有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1351,1,'1-u3wit23z','2026-06-13','支出','购物','现金',26,'武汉市悦购便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1352,1,'1-u3wit23z','2026-06-14','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1353,1,'1-u3wit23z','2026-06-14','支出','餐饮','现金',5,'土家酱香饼',NULL,NULL,'1-钱迹导入',NULL,0),(1354,1,'1-u3wit23z','2026-06-14','支出','餐饮','现金',9,'全興泰包子铺',NULL,NULL,'1-钱迹导入',NULL,0),(1355,1,'1-u3wit23z','2026-06-14','支出','餐饮','现金',2,'全興泰包子铺',NULL,NULL,'1-钱迹导入',NULL,0),(1356,1,'1-u3wit23z','2026-06-14','支出','医疗','现金',0,'武汉市东西湖区人民医院',NULL,NULL,'1-钱迹导入',NULL,0),(1357,1,'1-u3wit23z','2026-06-14','支出','餐饮','现金',12,'美团',NULL,NULL,'1-钱迹导入',NULL,0),(1358,1,'1-u3wit23z','2026-06-14','支出','餐饮','现金',13.4,'美团',NULL,NULL,'1-钱迹导入',NULL,0),(1359,1,'1-u3wit23z','2026-06-14','支出','餐饮','现金',21.19,'村长哥金银湖万达店',NULL,NULL,'1-钱迹导入',NULL,0),(1362,1,'1-u3wit23z','2026-06-15','支出','购物','现金',66.5,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1363,1,'1-u3wit23z','2026-06-16','支出','购物','现金',26,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1364,1,'1-u3wit23z','2026-06-16','支出','餐饮','现金',13,'收钱吧',NULL,NULL,'1-钱迹导入',NULL,0),(1365,1,'1-u3wit23z','2026-06-16','支出','购物','现金',3,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1366,1,'1-u3wit23z','2026-06-17','支出','餐饮','现金',100,'**珍',NULL,NULL,'1-钱迹导入',NULL,0),(1367,1,'1-u3wit23z','2026-06-17','支出','餐饮','现金',36.4,'冷记卤品（井岗店）',NULL,NULL,'1-钱迹导入',NULL,0),(1368,1,'1-u3wit23z','2026-06-18','支出','购物','现金',0.6,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1369,1,'1-u3wit23z','2026-06-18','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1370,1,'1-u3wit23z','2026-06-19','支出','购物','现金',4,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1371,1,'1-u3wit23z','2026-06-19','支出','餐饮','现金',16,'老柏泉小家常(吴家山店）',NULL,NULL,'1-钱迹导入',NULL,0),(1372,1,'1-u3wit23z','2026-06-19','支出','购物','现金',0.1,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1373,1,'1-u3wit23z','2026-06-19','支出','购物','现金',0.01,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1374,1,'1-u3wit23z','2026-06-19','支出','其他','现金',5.8,'广州市动景计算机科技有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1375,1,'1-u3wit23z','2026-06-19','支出','购物','现金',0.31,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1376,1,'1-u3wit23z','2026-06-19','支出','购物','现金',0.5,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1377,1,'1-u3wit23z','2026-06-20','支出','餐饮','现金',12,'土家酱香饼',NULL,NULL,'1-钱迹导入',NULL,0),(1378,1,'1-u3wit23z','2026-06-20','支出','餐饮','现金',12.5,'全興泰包子铺',NULL,NULL,'1-钱迹导入',NULL,0),(1379,1,'1-u3wit23z','2026-06-20','支出','购物','现金',0.1,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1380,1,'1-u3wit23z','2026-06-21','支出','购物','现金',0.1,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1381,1,'1-u3wit23z','2026-06-21','支出','购物','现金',29,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1382,1,'1-u3wit23z','2026-06-22','支出','餐饮','现金',10,'小店',NULL,NULL,'1-钱迹导入',NULL,0),(1383,1,'1-u3wit23z','2026-06-22','支出','餐饮','现金',5,'蒸旺手工大包',NULL,NULL,'1-钱迹导入',NULL,0),(1384,1,'1-u3wit23z','2026-06-23','支出','购物','现金',74,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1385,1,'1-u3wit23z','2026-06-23','支出','购物','现金',9.9,'良品铺子(东西湖万达广场店)',NULL,NULL,'1-钱迹导入',NULL,0),(1386,1,'1-u3wit23z','2026-06-23','支出','购物','现金',26,'井岗便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1387,1,'1-u3wit23z','2026-06-23','支出','购物','现金',0,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1388,1,'1-u3wit23z','2026-06-24','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1389,1,'1-u3wit23z','2026-06-24','支出','餐饮','现金',15,'小店',NULL,NULL,'1-钱迹导入',NULL,0),(1390,1,'1-u3wit23z','2026-06-24','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1391,1,'1-u3wit23z','2026-06-24','支出','其他','现金',2,'柏来科技',NULL,NULL,'1-钱迹导入',NULL,0),(1392,1,'1-u3wit23z','2026-06-24','支出','餐饮','现金',15,'收钱吧',NULL,NULL,'1-钱迹导入',NULL,0),(1393,1,'1-u3wit23z','2026-06-25','支出','餐饮','现金',13,'老黄牛牛骨面馆',NULL,NULL,'1-钱迹导入',NULL,0),(1394,1,'1-u3wit23z','2026-06-25','支出','购物','现金',140,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1395,1,'1-u3wit23z','2026-06-26','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1396,1,'1-u3wit23z','2026-06-26','支出','购物','现金',3,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1397,1,'1-u3wit23z','2026-06-26','支出','餐饮','现金',8,'文静蔬菜生鲜',NULL,NULL,'1-钱迹导入',NULL,0),(1398,1,'1-u3wit23z','2026-06-26','支出','购物','现金',25,'军秀超巿',NULL,NULL,'1-钱迹导入',NULL,0),(1399,1,'1-u3wit23z','2026-06-27','支出','餐饮','现金',46,'老柏泉小家常(吴家山店）',NULL,NULL,'1-钱迹导入',NULL,0),(1400,1,'1-u3wit23z','2026-06-27','支出','娱乐','现金',10,'武汉市东西湖区小手造物游戏乐园中心',NULL,NULL,'1-钱迹导入',NULL,0),(1401,1,'1-u3wit23z','2026-06-29','支出','餐饮','现金',7.5,'小店',NULL,NULL,'1-钱迹导入',NULL,0),(1402,1,'1-u3wit23z','2026-06-29','支出','餐饮','现金',3,'小店',NULL,NULL,'1-钱迹导入',NULL,0),(1403,1,'1-u3wit23z','2026-06-29','支出','购物','现金',25.75,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1404,1,'1-u3wit23z','2026-06-29','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1405,1,'1-u3wit23z','2026-06-29','支出','购物','现金',1,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1406,1,'1-u3wit23z','2026-06-29','支出','餐饮','现金',21.42,'大米先生（湖北武汉荟聚店）',NULL,NULL,'1-钱迹导入',NULL,0),(1407,1,'1-u3wit23z','2026-06-30','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1408,1,'1-u3wit23z','2026-07-01','支出','购物','现金',31.83,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1409,1,'1-u3wit23z','2026-07-01','支出','餐饮','现金',5,'胖胖牛肉面',NULL,NULL,'1-钱迹导入',NULL,0),(1410,1,'1-u3wit23z','2026-07-01','支出','购物','现金',3,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1411,1,'1-u3wit23z','2026-07-01','支出','餐饮','现金',27,'四季鲜水果店',NULL,NULL,'1-钱迹导入',NULL,0),(1412,1,'1-u3wit23z','2026-07-01','支出','购物','现金',502,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1413,1,'1-u3wit23z','2026-07-02','支出','餐饮','现金',4.87,'胖胖牛肉面',NULL,NULL,'1-钱迹导入',NULL,0),(1414,1,'1-u3wit23z','2026-07-02','支出','餐饮','现金',5,'冷记卤品（井岗店）',NULL,NULL,'1-钱迹导入',NULL,0),(1415,1,'1-u3wit23z','2026-07-02','支出','交通','现金',2,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1416,1,'1-u3wit23z','2026-07-02','支出','通讯','现金',99,'小米移动',NULL,NULL,'1-钱迹导入',NULL,0),(1417,1,'1-u3wit23z','2026-07-02','支出','购物','现金',25.8,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1418,1,'1-u3wit23z','2026-07-03','支出','餐饮','现金',4.73,'精致鲜包',NULL,NULL,'1-钱迹导入',NULL,0),(1419,1,'1-u3wit23z','2026-07-03','支出','购物','现金',26,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1420,1,'1-u3wit23z','2026-07-04','支出','购物','现金',0.1,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1421,1,'1-u3wit23z','2026-07-05','支出','餐饮','现金',13.5,'土猪肉',NULL,NULL,'1-钱迹导入',NULL,0),(1422,1,'1-u3wit23z','2026-07-05','支出','餐饮','现金',5,'蔬菜摊',NULL,NULL,'1-钱迹导入',NULL,0),(1423,1,'1-u3wit23z','2026-07-05','支出','餐饮','现金',11.9,'武汉市东西湖夫妻菜店',NULL,NULL,'1-钱迹导入',NULL,0),(1424,1,'1-u3wit23z','2026-07-05','支出','购物','现金',6.79,'军秀超巿',NULL,NULL,'1-钱迹导入',NULL,0),(1425,1,'1-u3wit23z','2026-07-06','支出','购物','现金',25.77,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1426,1,'1-u3wit23z','2026-07-07','支出','餐饮','现金',18,'饸饹面手擀面',NULL,NULL,'1-钱迹导入',NULL,0),(1427,1,'1-u3wit23z','2026-07-07','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1428,1,'1-u3wit23z','2026-07-07','支出','购物','现金',15,'湖北悦联商业管理有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1429,1,'1-u3wit23z','2026-07-07','支出','购物','现金',4,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1430,1,'1-u3wit23z','2026-07-08','支出','购物','现金',27,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1431,1,'1-u3wit23z','2026-07-08','支出','餐饮','现金',18,'饸饹面手擀面',NULL,NULL,'1-钱迹导入',NULL,0),(1432,1,'1-u3wit23z','2026-07-09','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1433,1,'1-u3wit23z','2026-07-09','支出','购物','现金',7,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1434,1,'1-u3wit23z','2026-07-09','支出','餐饮','现金',6,'饸饹面手擀面',NULL,NULL,'1-钱迹导入',NULL,0),(1435,1,'1-u3wit23z','2026-07-09','支出','通讯','现金',5,'北京小米移动软件有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1436,1,'1-u3wit23z','2026-07-10','支出','购物','现金',1.71,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1437,1,'1-u3wit23z','2026-07-10','支出','餐饮','现金',8,'饸饹面手擀面',NULL,NULL,'1-钱迹导入',NULL,0),(1438,1,'1-u3wit23z','2026-07-10','支出','餐饮','现金',9,'收钱吧',NULL,NULL,'1-钱迹导入',NULL,0),(1439,1,'1-u3wit23z','2026-07-10','支出','其他','现金',100,'°',NULL,NULL,'1-钱迹导入',NULL,0),(1440,1,'1-u3wit23z','2026-07-10','支出','购物','现金',112.8,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1441,1,'1-u3wit23z','2026-07-11','支出','购物','现金',232.5,'湖北悦联商业管理有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1442,1,'1-u3wit23z','2026-07-11','支出','购物','现金',25,'熙尚便利店',NULL,NULL,'1-钱迹导入',NULL,0),(1443,1,'1-u3wit23z','2026-07-11','支出','其他','现金',20,'杭州深度求索人工智能基础技术研究有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1444,1,'1-u3wit23z','2026-07-11','支出','餐饮','现金',90,'老柏泉小家常(吴家山店）',NULL,NULL,'1-钱迹导入',NULL,0),(1445,1,'1-u3wit23z','2026-07-11','收入','转账','现金',1,'转账',NULL,NULL,'1-钱迹导入',NULL,0),(1446,1,'1-u3wit23z','2026-07-12','支出','购物','现金',10,'优鲜购生鲜超市',NULL,NULL,'1-钱迹导入',NULL,0),(1447,1,'1-u3wit23z','2026-07-12','支出','餐饮','现金',43,'老柏泉小家常(吴家山店）',NULL,NULL,'1-钱迹导入',NULL,0),(1448,1,'1-u3wit23z','2026-07-12','支出','其他','现金',2,'柏来科技',NULL,NULL,'1-钱迹导入',NULL,0),(1449,1,'1-u3wit23z','2026-07-14','支出','购物','现金',3,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1450,1,'1-u3wit23z','2026-07-14','支出','娱乐','现金',50,'中国福利彩票',NULL,NULL,'1-钱迹导入',NULL,0),(1451,1,'1-u3wit23z','2026-07-14','支出','娱乐','现金',150,'中国福利彩票',NULL,NULL,'1-钱迹导入',NULL,0),(1452,1,'1-u3wit23z','2026-07-14','支出','娱乐','现金',10,'中国福利彩票',NULL,NULL,'1-钱迹导入',NULL,0),(1454,1,'1-u3wit23z','2026-07-15','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1455,1,'1-u3wit23z','2026-07-16','支出','其他','现金',28,'琪诚',NULL,NULL,'1-钱迹导入',NULL,0),(1456,1,'1-u3wit23z','2026-07-16','支出','餐饮','现金',5,'小浚园热干面南湖店',NULL,NULL,'1-钱迹导入',NULL,0),(1457,1,'1-u3wit23z','2026-07-16','支出','餐饮','现金',7.5,'九龙王大包南湖直营店',NULL,NULL,'1-钱迹导入',NULL,0),(1458,1,'1-u3wit23z','2026-07-15','支出','餐饮','现金',8,'饸饹面手擀面',NULL,NULL,'1-钱迹导入',NULL,0),(1459,1,'1-u3wit23z','2026-07-15','支出','购物','现金',25,'琪成评价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1460,1,'1-u3wit23z','2026-07-15','支出','购物','现金',33.26,'优鲜购生鲜超市',NULL,NULL,'1-钱迹导入',NULL,0),(1461,1,'1-u3wit23z','2026-07-16','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1462,1,'1-u3wit23z','2026-07-16','支出','通讯','现金',50,'中国电信',NULL,NULL,'1-钱迹导入',NULL,0),(1463,1,'1-u3wit23z','2026-07-17','支出','餐饮','现金',7,'土家酱香饼',NULL,NULL,'1-钱迹导入',NULL,0),(1464,1,'1-u3wit23z','2026-07-17','支出','餐饮','现金',4,'阿飞',NULL,NULL,'1-钱迹导入',NULL,0),(1465,1,'1-u3wit23z','2026-07-18','支出','其他','现金',25,'琪诚',NULL,NULL,'1-钱迹导入',NULL,0),(1466,1,'1-u3wit23z','2026-07-17','支出','购物','现金',195,'闲鱼',NULL,NULL,'1-钱迹导入',NULL,0),(1467,1,'1-u3wit23z','2026-07-17','支出','餐饮','现金',9,'武汉市硚口区家菊铁板烧店',NULL,NULL,'1-钱迹导入',NULL,0),(1468,1,'1-u3wit23z','2026-07-18','支出','餐饮','现金',6,'九龙王大包南湖直营店',NULL,NULL,'1-钱迹导入',NULL,0),(1469,1,'1-u3wit23z','2026-07-18','支出','其他','现金',20,'杭州深度求索人工智能基础技术研究有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1470,1,'1-u3wit23z','2026-07-19','支出','购物','现金',7,'平价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1471,1,'1-u3wit23z','2026-07-19','支出','交通','现金',1,'中国铁路武汉局集团有限公司武汉房建生活段',NULL,NULL,'1-钱迹导入',NULL,0),(1472,1,'1-u3wit23z','2026-07-18','支出','购物','现金',9,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1473,1,'1-u3wit23z','2026-07-19','支出','购物','现金',14,'万嘉烟酒',NULL,NULL,'1-钱迹导入',NULL,0),(1474,1,'1-u3wit23z','2026-07-19','支出','其他','现金',25,'夸克网盘',NULL,NULL,'1-钱迹导入',NULL,0),(1475,1,'1-u3wit23z','2026-07-19','支出','交通','现金',9,'中国铁路武汉局集团有限公司武汉房建生活段',NULL,NULL,'1-钱迹导入',NULL,0),(1476,1,'1-u3wit23z','2026-07-19','支出','购物','现金',15,'平价超市',NULL,NULL,'1-钱迹导入',NULL,0),(1477,1,'1-u3wit23z','2026-07-19','支出','餐饮','现金',8.64,'好想来零食乐园',NULL,NULL,'1-钱迹导入',NULL,0),(1478,1,'1-u3wit23z','2026-07-20','支出','转账','现金',1,'微信转账',NULL,NULL,'1-钱迹导入',NULL,0),(1479,1,'1-u3wit23z','2026-07-20','支出','住房','现金',8,'合肥房建公寓段',NULL,NULL,'1-钱迹导入',NULL,0),(1480,1,'1-u3wit23z','2026-07-20','支出','购物','现金',16.3,'淘宝闪购极速版',NULL,NULL,'1-钱迹导入',NULL,0),(1481,1,'1-u3wit23z','2026-07-21','支出','餐饮','现金',8,'梅记汉口热干面',NULL,NULL,'1-钱迹导入',NULL,0),(1482,1,'1-u3wit23z','2026-07-21','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1483,1,'1-u3wit23z','2026-07-21','支出','购物','现金',28,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1484,1,'1-u3wit23z','2026-07-21','支出','餐饮','现金',79,'美团',NULL,NULL,'1-钱迹导入',NULL,0),(1485,1,'1-u3wit23z','2026-07-21','支出','餐饮','现金',95.5,'美团',NULL,NULL,'1-钱迹导入',NULL,0),(1486,1,'1-u3wit23z','2026-07-21','支出','其他','现金',2.2,'武汉芯果依达企业管理有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1487,1,'1-u3wit23z','2026-07-22','支出','餐饮','现金',13.2,'大米先生(东西湖万达店)',NULL,NULL,'1-钱迹导入',NULL,0),(1488,1,'1-u3wit23z','2026-07-22','支出','餐饮','现金',18,'武汉（詹记）东西湖万达店',NULL,NULL,'1-钱迹导入',NULL,0),(1489,1,'1-u3wit23z','2026-07-22','支出','餐饮','现金',30.6,'透响麻辣香锅',NULL,NULL,'1-钱迹导入',NULL,0),(1490,1,'1-u3wit23z','2026-07-22','支出','购物','现金',3.9,'叮当生活超市万达店',NULL,NULL,'1-钱迹导入',NULL,0),(1491,1,'1-u3wit23z','2026-07-23','支出','餐饮','现金',15,'夏小胖鲜肚面',NULL,NULL,'1-钱迹导入',NULL,0),(1492,1,'1-u3wit23z','2026-07-23','支出','购物','现金',29,'武汉市东西湖区家家福便利超市',NULL,NULL,'1-钱迹导入',NULL,0),(1493,1,'1-u3wit23z','2026-07-23','支出','餐饮','现金',4,'九龙王大包南湖直营店',NULL,NULL,'1-钱迹导入',NULL,0),(1498,1,'1-u3wit23z','2026-07-23','支出','交通','现金',7,'武汉地铁运营有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1508,1,'1-u3wit23z','2026-07-24','收入','餐饮','现金',79,'美团平台商户',NULL,NULL,'1-钱迹导入',NULL,0),(1509,1,'1-u3wit23z','2026-07-24','支出','其他','现金',10,'杭州深度求索人工智能基础技术研究有限公司',NULL,NULL,'1-钱迹导入',NULL,0),(1510,1,'1-u3wit23z','2026-07-25','支出','餐饮','现金',25.2,'美团',NULL,NULL,'1-钱迹导入',NULL,0),(1511,1,'1-u3wit23z','2026-07-25','支出','通讯','现金',30,'中国移动和包',NULL,NULL,'1-钱迹导入',NULL,0),(1512,1,'1-u3wit23z','2026-07-25','支出','餐饮','现金',38.89,'好想来零食乐园',NULL,NULL,'1-钱迹导入',NULL,0),(1513,1,'1-u3wit23z','2026-07-25','支出','餐饮','现金',44.54,'好想来零食乐园',NULL,NULL,'1-钱迹导入',NULL,0);
/*!40000 ALTER TABLE `flows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receivables`
--

DROP TABLE IF EXISTS `receivables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receivables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `occur_id` int DEFAULT NULL,
  `actual_id` int DEFAULT NULL,
  `book_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `occur_day` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expect_day` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actual_day` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `money` float DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receivables`
--

LOCK TABLES `receivables` WRITE;
/*!40000 ALTER TABLE `receivables` DISABLE KEYS */;
/*!40000 ALTER TABLE `receivables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_register` tinyint(1) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_by` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_relations`
--

DROP TABLE IF EXISTS `type_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `type_relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `book_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_relations`
--

LOCK TABLES `type_relations` WRITE;
/*!40000 ALTER TABLE `type_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2b$12$AXCmQRQYUByfY8AejE6Cjug6hCLY8jte6Ro4pHQyHiywRcM3UCiG6','管理员',NULL,'2026-07-20 12:49:34'),(2,'wml','$2b$12$FvpslsoEtni4O0Xvn3.o7eJvhZ9JPi7NfzMEWo77.hQgolubuBozy','wml',NULL,'2026-07-20 13:15:16'),(3,'mqy','$2b$12$fuufdns1QzemsYnFQucqfesAQNUZNwF7fCcNJvSFf69G9pZmqqUHy','mqy',NULL,'2026-07-20 13:16:51'),(4,'test','$2b$12$o1FutVq5luICtqc8PqSftew5hObPXTSENjc5pf0OB7SqytsMygiKi','测试',NULL,'2026-07-21 07:32:34'),(5,'liu','$2b$12$TV0QkP2jyMFscChxxyp3TulIsED8V14TK4jSpPTwy3jmuloorb6Na','刘大珍',NULL,'2026-07-21 07:32:42'),(6,'demo','$2b$12$dMhrXohstQ.9.boi0ANhle34AOCGdORSPF2JpavFgp88u5tk7WFUG','demo',NULL,'2026-07-21 08:04:13'),(7,'123','$2b$12$lpWrKkhA6JH4M4G0.EaIhO4Bq63xTMk0nTVPZXZaGdkeVGTuF7t46','演示用户',NULL,'2026-07-21 08:04:24'),(8,'刘123456','$2b$12$l0N9ric6O5AUtp8vx3fr5uqx/ngzDdWZHbfsULcz/auo7oNWaqZny','女神',NULL,'2026-07-21 12:59:47');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-25 23:30:10
